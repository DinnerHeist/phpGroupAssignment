-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2020 at 03:56 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group_assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `ApprovalID` int(10) UNSIGNED NOT NULL,
  `StaffName` varchar(50) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `DateTime` datetime NOT NULL DEFAULT current_timestamp(),
  `Status` enum('TRUSTED','UNTRUSTED','','') NOT NULL,
  `Comments` varchar(255) DEFAULT '',
  `Approved` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`ApprovalID`, `StaffName`, `CustomerID`, `DateTime`, `Status`, `Comments`, `Approved`) VALUES
(25, 'Jake', 123, '2020-11-16 21:50:51', 'UNTRUSTED', '', 1),
(30, 'Jake', 123, '2020-11-16 23:11:55', 'UNTRUSTED', 'reason', 1),
(31, 'Jake', 123, '2020-11-17 14:28:49', 'TRUSTED', 'reason', 1),
(32, 'Joe Kane', 124, '2020-11-17 15:38:21', 'UNTRUSTED', '', 1),
(33, 'Jake', 123, '2020-11-17 16:38:54', 'UNTRUSTED', 'reason', 1),
(34, 'Jake', 123, '2020-11-17 16:39:06', 'TRUSTED', 'reason', 1),
(35, 'Jake', 123, '2020-11-17 16:40:27', 'UNTRUSTED', 'reason', 0);

-- --------------------------------------------------------

--
-- Table structure for table `checking_of_service_and_status`
--

CREATE TABLE `checking_of_service_and_status` (
  `trackingNumber` int(50) NOT NULL,
  `availableForPickup` varchar(20) NOT NULL,
  `exception` varchar(20) NOT NULL,
  `expired` varchar(20) NOT NULL,
  `pending` varchar(20) NOT NULL,
  `outOfDelivery` varchar(20) NOT NULL,
  `received` varchar(20) NOT NULL,
  `itemName` varchar(30) NOT NULL,
  `deliveryID` varchar(20) NOT NULL,
  `paid` varchar(20) NOT NULL,
  `returned` varchar(20) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `estimatedDeliveryDateTime` varchar(20) NOT NULL,
  `wayBillNumber` varchar(20) NOT NULL,
  `nextStep` varchar(10) NOT NULL,
  `description` varchar(100) NOT NULL,
  `RequestNumber` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checking_of_service_and_status`
--

INSERT INTO `checking_of_service_and_status` (`trackingNumber`, `availableForPickup`, `exception`, `expired`, `pending`, `outOfDelivery`, `received`, `itemName`, `deliveryID`, `paid`, `returned`, `destination`, `estimatedDeliveryDateTime`, `wayBillNumber`, `nextStep`, `description`, `RequestNumber`) VALUES
(73, 'NO', '', '', 'YES', 'NO', 'NO', '', '', '', '', 'Kuala Lumpur', '', '', '', 'Johor to Kul', 1336);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(10) UNSIGNED NOT NULL,
  `Title` enum('Dr.','Mr.','Ms.','Mrs.','Miss.') CHARACTER SET utf16 DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf16 NOT NULL,
  `Email` varchar(254) CHARACTER SET utf16 NOT NULL,
  `Phone` varchar(50) CHARACTER SET utf16 NOT NULL,
  `Company` varchar(50) CHARACTER SET utf16 NOT NULL,
  `Country` varchar(50) CHARACTER SET utf16 NOT NULL,
  `PostalCode` varchar(20) CHARACTER SET utf16 NOT NULL,
  `City` varchar(50) CHARACTER SET utf16 NOT NULL,
  `State` varchar(50) CHARACTER SET utf16 NOT NULL,
  `Address` varchar(255) CHARACTER SET utf16 NOT NULL,
  `Status` enum('TRUSTED','UNTRUSTED') CHARACTER SET utf16 NOT NULL DEFAULT 'TRUSTED',
  `Comments` varchar(255) NOT NULL DEFAULT '',
  `Password` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `Title`, `Name`, `Email`, `Phone`, `Company`, `Country`, `PostalCode`, `City`, `State`, `Address`, `Status`, `Comments`, `Password`) VALUES
(123, NULL, 'Customer', 'customer@gmail.com', '0123456789', 'Company', 'Country', '12345', 'City', 'State', 'Address', 'TRUSTED', 'reason', 123),
(124, NULL, 'Customer', 'customer@gmail.com', '0123456789', 'Company', 'Country', '12345', 'City', 'State', 'address', 'UNTRUSTED', '', 123),
(143, '', 'Jake', 'jake@gmail.com', '+60123081836', '123', 'Malaysia', 'postalcode', 'city', 'state', '123', 'TRUSTED', '', 123);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_schedule`
--

CREATE TABLE `delivery_schedule` (
  `ScheduleID` int(4) NOT NULL,
  `CustomerID` int(4) DEFAULT NULL,
  `OrderID` int(4) DEFAULT NULL,
  `SupplierID` int(4) DEFAULT NULL,
  `DeliveryDate` date NOT NULL,
  `DeliveryStatus` varchar(45) NOT NULL,
  `PaymentID` int(4) DEFAULT NULL,
  `BillingName` varchar(45) NOT NULL,
  `OriginLocation` varchar(255) NOT NULL,
  `DestinationLocation` varchar(255) NOT NULL,
  `DeliveryMode` varchar(45) NOT NULL,
  `UnitPrice` decimal(17,0) NOT NULL,
  `MaximumCapasity` int(11) NOT NULL,
  `EstimatedTimeDelivery` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery_schedule`
--

INSERT INTO `delivery_schedule` (`ScheduleID`, `CustomerID`, `OrderID`, `SupplierID`, `DeliveryDate`, `DeliveryStatus`, `PaymentID`, `BillingName`, `OriginLocation`, `DestinationLocation`, `DeliveryMode`, `UnitPrice`, `MaximumCapasity`, `EstimatedTimeDelivery`) VALUES
(1234, 1234, 1234, 1234, '2020-11-06', 'DELIVERED\n', 1234, 'NAME', 'Malaysia\n', 'Singapore\n', 'Air Freight\n', '1000', 100, 4),
(1269, NULL, NULL, NULL, '0000-00-00', '123\n', NULL, '123\n', '2020-11-05\n', '123\n', '123\n', '123', 123, 123);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` varchar(34) NOT NULL,
  `InvoiceID` int(34) NOT NULL,
  `OrderID` varchar(100) NOT NULL,
  `InvoiceNumber` varchar(34) NOT NULL,
  `InvoiceDate` date NOT NULL,
  `BillingName` varchar(20) NOT NULL,
  `Amount` int(255) NOT NULL,
  `AccountNo` int(34) NOT NULL,
  `PaymentType` varchar(20) NOT NULL,
  `PaymentDate` date NOT NULL,
  `TransactionNumber` varchar(12) NOT NULL,
  `Comments` varchar(150) NOT NULL,
  `RequestNumber` int(7) NOT NULL,
  `CreditCardNumber` int(16) NOT NULL,
  `TransportType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `InvoiceID`, `OrderID`, `InvoiceNumber`, `InvoiceDate`, `BillingName`, `Amount`, `AccountNo`, `PaymentType`, `PaymentDate`, `TransactionNumber`, `Comments`, `RequestNumber`, `CreditCardNumber`, `TransportType`) VALUES
('', 2334952, '', '', '2020-11-21', 'Jake', 100, 3333, '', '2020-11-21', '', 'Johor to Kul', 1336, 3333, 'Air Freight');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `RequestNumber` int(10) NOT NULL,
  `ClientID` varchar(10) NOT NULL,
  `ClientName` varchar(30) NOT NULL,
  `ContactNumber` int(11) NOT NULL,
  `ClientAddress` varchar(60) NOT NULL,
  `DeliveryService` varchar(15) NOT NULL,
  `ShippingDate` date NOT NULL,
  `ShippingLocation` varchar(60) NOT NULL,
  `TransportationType` varchar(30) NOT NULL,
  `Capacity` varchar(20) NOT NULL,
  `CreditCardNo` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`RequestNumber`, `ClientID`, `ClientName`, `ContactNumber`, `ClientAddress`, `DeliveryService`, `ShippingDate`, `ShippingLocation`, `TransportationType`, `Capacity`, `CreditCardNo`) VALUES
(1336, '', 'Jake', 3333, 'Johor', 'Domestic', '2020-11-21', 'Kuala Lumpur', 'Air Freight', '10', 3333);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `transportID` int(11) NOT NULL,
  `Transportation` varchar(50) NOT NULL,
  `Price` double NOT NULL,
  `Distance` double NOT NULL,
  `Capacity` double NOT NULL,
  `ForeignTaxation` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`transportID`, `Transportation`, `Price`, `Distance`, `Capacity`, `ForeignTaxation`) VALUES
(1234, 'Air Freight', 100, 1000, 70, 0.1),
(1235, 'Ocean Freight', 50, 1000, 70, 0.2);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` varchar(50) NOT NULL,
  `Position` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Salary` double NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `Position`, `Name`, `Email`, `Phone`, `Department`, `Salary`, `Password`) VALUES
('J19029955', 'manager', 'Jake', 'jake@gmail.com', '1234', 'sales', 5000, '123'),
('J19029956', 'employee', 'Joe Kane', 'kane@gmail.com', '1234', 'sales', 6000, '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`ApprovalID`);

--
-- Indexes for table `checking_of_service_and_status`
--
ALTER TABLE `checking_of_service_and_status`
  ADD PRIMARY KEY (`trackingNumber`),
  ADD KEY `order` (`RequestNumber`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `delivery_schedule`
--
ALTER TABLE `delivery_schedule`
  ADD PRIMARY KEY (`ScheduleID`),
  ADD UNIQUE KEY `OrderID` (`OrderID`,`SupplierID`,`PaymentID`),
  ADD UNIQUE KEY `CustomerID` (`CustomerID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD UNIQUE KEY `InvoiceID` (`InvoiceID`),
  ADD UNIQUE KEY `RequestNumber` (`RequestNumber`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`RequestNumber`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`transportID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `ApprovalID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `checking_of_service_and_status`
--
ALTER TABLE `checking_of_service_and_status`
  MODIFY `trackingNumber` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `delivery_schedule`
--
ALTER TABLE `delivery_schedule`
  MODIFY `ScheduleID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1270;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `InvoiceID` int(34) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2334953;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `RequestNumber` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1337;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `transportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1236;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checking_of_service_and_status`
--
ALTER TABLE `checking_of_service_and_status`
  ADD CONSTRAINT `order` FOREIGN KEY (`RequestNumber`) REFERENCES `request` (`RequestNumber`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `request` FOREIGN KEY (`RequestNumber`) REFERENCES `request` (`RequestNumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
